Raphael.fn.pieChart = function (cx, cy, r, values, labels, stroke,dist) {
    var paper = this,
        rad = Math.PI / 180,
        chart = this.set();
    function sector(cx, cy, r, startAngle, endAngle, params, dist) {
        var cy = cy + dist * Math.sin(-(startAngle+(endAngle-startAngle)/2) * rad),
            cx = cx + dist * Math.cos(-(startAngle+(endAngle-startAngle)/2) * rad),
            x1 = cx + r * Math.cos(-startAngle * rad),
            x2 = cx + r * Math.cos(-endAngle * rad),
            y1 = cy + r * Math.sin(-startAngle * rad),
            y2 = cy + r * Math.sin(-endAngle * rad);
        return paper.path(["M", cx, cy, "L", x1, y1, "A", r, r, 0, +(endAngle - startAngle > 180), 0, x2, y2, "z"]).attr(params);
    }
    var angle = 0,
        total = 0,
        start = 0,
        radiuss = [90,40,20,0,20,45,-10,30],
        process = function (j) {
            var value = values[j],
                angleplus = 360 * value / total,
                popangle = angle + (angleplus / 2),
                color = Raphael.hsb(start, .75, 1),
                ms = 500,
                bcolor = Raphael.hsb(start, 1, 1),
                p = sector(cx, cy, r+radiuss[j], angle, angle + angleplus, {fill: "#007F88", stroke: stroke, "stroke-width": 10, cursor:'pointer',background:"url('hello.png') no-repeat"},dist),
                txt = paper.text(cx + (r+radiuss[j]) * 0.6 * Math.cos(-popangle * rad), cy + (r+radiuss[j]) * 0.6 * Math.sin(-popangle * rad), labels[j].title).attr({fill: 'white', stroke: "none", opacity: 0, "font-size": 26, "font-family":"alienlang"});
            p.mouseover(function () {
                p.stop().animate({transform: "s1.02 1.02 " + cx + " " + cy}, ms, "elastic");
                p.attr({fill:'#049296'});
                txt.stop().animate({opacity: 1}, ms, "elastic");
            }).mouseout(function () {
                p.stop().animate({transform: ""}, ms, "elastic");
                p.attr({fill:'#007F88'});
                txt.stop().animate({opacity: 0}, ms);
            });
            angle += angleplus;
            chart.push(p);
            chart.push(txt);
            start += .1;
        };
    for (var i = 0, ii = values.length; i < ii; i++) {
        total += values[i];
    }
    for (i = 0; i < ii; i++) {
        process(i);
    }
    paper.circle(cx,cy,r*0.45).attr({fill:"black"});
    paper.text('impetus15').attr({fill: 'white', stroke: "none", "font-size": 26, "font-family":"alienlang"});
    return chart;
};

(function(){
	var height = Math.max(Math.round($(window).height()*0.8),650),
		width = Math.max(Math.round($(window).width()*0.8),650);
	width = Math.min(height,width);
	var	mu = window.innerHeight*0.5-width*0.5,
		ms = window.innerWidth*0.5-width*0.5,
		values = [45,45,45,45,45,45,45,45],
		labels = {};

	angular.module('startPage',[])
		.factory('imp_server',function($http){
			var getCatagories = function(){
				return $http.get('src/getCatagories.php');
			}
			return{
				getCatagories : getCatagories
			};
		})
		.controller('startCtrl',function($scope,$rootScope,imp_server){
			$rootScope.titleText = "Impetus 15";
			
			$('#st_container').css('margin',Math.round(mu)+'px '+Math.round(ms)+'px');

			imp_server.getCatagories()
				.success(function(data){
					labels = data;
					console.log(labels);
				})
				.error(function(e){
					$rootScope.notify = "Server Communication failed";
				})
		});

	Raphael("st_space", width, width).pieChart(width*0.5, width*0.5, width*0.3, values, labels, "rgba(0,0,0,0)",10);
})();